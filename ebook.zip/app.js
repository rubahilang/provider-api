const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const fs = require('fs');
const { GoogleGenerativeAI } = require("@google/generative-ai");
const { v4: uuidv4 } = require('uuid'); // Untuk membuat ID unik
const JSON5 = require('json5'); // Library parsing JSON yang lebih toleran

// Membaca API key dari key.json
const keyPath = path.join(__dirname, 'key.json');
if (!fs.existsSync(keyPath)) {
    console.error("File key.json tidak ditemukan.");
    process.exit(1);
}
const keyData = JSON.parse(fs.readFileSync(keyPath, 'utf-8'));
const API_KEY = keyData.API_KEY;

if (!API_KEY) {
    console.error("API_KEY tidak ditemukan dalam key.json.");
    process.exit(1);
}

// Inisialisasi Generative AI
const genAI = new GoogleGenerativeAI(API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

const app = express();

// Mengatur view engine ke EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware untuk parsing form data
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Folder untuk menyimpan e-book sementara
const ebooksDir = path.join(__dirname, 'ebooks');
if (!fs.existsSync(ebooksDir)) {
    fs.mkdirSync(ebooksDir);
}

// Simpan data e-book dalam memori sederhana (untuk demo)
const ebooks = {};

// Route untuk halaman utama
app.get('/', (req, res) => {
    res.render('index');
});

// Fungsi untuk membersihkan dan memvalidasi JSON
function cleanJsonString(jsonString) {
    // Hapus karakter kontrol non-printable
    return jsonString.replace(/[\u0000-\u001F\u007F-\u009F]/g, "");
}

// Fungsi untuk mencoba parsing JSON dengan percobaan ulang menggunakan JSON5
function parseJsonWithRetry(jsonString, retries = 3) {
    for (let i = 0; i < retries; i++) {
        try {
            return JSON5.parse(jsonString);
        } catch (error) {
            console.warn(`Percobaan parsing JSON ke-${i + 1} gagal:`, error.message);
            // Coba hapus karakter kontrol lagi
            jsonString = cleanJsonString(jsonString);
        }
    }
    throw new Error("Tidak dapat memperbaiki JSON setelah beberapa percobaan.");
}

// Fungsi untuk mengganti asteris dengan tag HTML yang sesuai
function replaceAsterisWithHTML(content) {
    // Mengganti **text** atau __text__ dengan <b>text</b>
    content = content.replace(/(\*\*|__)(.*?)\1/g, '<b>$2</b>');
    // Mengganti *text* atau _text_ dengan <i>$2</i>
    content = content.replace(/(\*|_)(.*?)\1/g, '<i>$2</i>');
    // Menghapus asteris yang tersisa
    content = content.replace(/\*/g, '');
    return content;
}

// Fungsi untuk menghitung jumlah kata
function countWords(text) {
    return text.split(/\s+/).filter(word => word.length > 0).length;
}

// Fungsi untuk menghasilkan bab dengan validasi jumlah kata dan kelanjutan jika diperlukan
async function generateChapter(model, initialPrompt, minWords, maxWords, maxRetries = 10) {
    let finalContent = '';
    let attempts = 0;
    let previousWordCount = 0;

    // Langkah 1: Generasi Awal
    while (attempts < maxRetries) {
        attempts++;
        try {
            const initialResult = await model.generateContent(initialPrompt);
            let initialResponseText = initialResult.response.text().replace(/```json|```/g, '').trim();

            // Bersihkan string JSON
            initialResponseText = cleanJsonString(initialResponseText);

            // Logging tambahan untuk debugging
            console.log(`Respons AI untuk generasi bab (Percobaan ${attempts}):`, initialResponseText);

            // Parsing JSON dari respons awal dengan percobaan ulang
            let initialJson;
            try {
                initialJson = parseJsonWithRetry(initialResponseText, 3);
            } catch (parseError) {
                console.warn(`Percobaan ${attempts}: Parsing JSON awal gagal: ${parseError.message}`);
                // Tambahkan instruksi tambahan dan coba ulang
                initialPrompt += "\n\nCatatan: Pastikan untuk mengembalikan JSON yang valid tanpa karakter kontrol atau kesalahan format.";
                continue; // Coba lagi
            }

            if (!initialJson.content) {
                throw new Error("Field 'content' tidak ditemukan dalam JSON respons awal.");
            }

            finalContent = initialJson.content.trim();
            previousWordCount = countWords(finalContent);

            // Hitung jumlah kata
            let wordCount = previousWordCount;
            console.log(`Generasi awal: ${wordCount} kata.`);

            // Jika jumlah kata sudah memenuhi, potong jika perlu dan kembalikan
            if (wordCount >= minWords) {
                if (wordCount > maxWords) {
                    finalContent = finalContent.split(/\s+/).slice(0, maxWords).join(' ');
                }
                // Ganti asteris dengan HTML
                finalContent = replaceAsterisWithHTML(finalContent);
                return finalContent;
            }

            // Jika jumlah kata kurang, lanjut ke kelanjutan
            break;
        } catch (error) {
            console.error(`Percobaan ${attempts}: Error pada generasi awal:`, error);
            if (attempts >= maxRetries) {
                // Jika sudah mencapai maxRetries, return konten terakhir meskipun < minWords
                console.warn(`Percobaan ${attempts}: Tidak dapat mencapai jumlah kata minimal. Menggunakan konten terakhir.`);
                finalContent = replaceAsterisWithHTML(finalContent);
                return finalContent;
            }
        }
    }

    // Langkah 2: Kelanjutan Konten jika diperlukan
    while (countWords(finalContent) < minWords && attempts < maxRetries) {
        attempts++;
        try {
            const continuationPrompt = `
Lanjutkan teks berikut tanpa mengulang atau menyimpang dari konten sebelumnya. Buatlah bab ini lebih detail, mendalam, dan lebih panjang hingga 2x lipat. Pastikan setiap bagian terstruktur dengan baik dan koheren:

${finalContent}
`;

            const continuationResult = await model.generateContent(continuationPrompt);
            let continuationText = continuationResult.response.text().replace(/```json|```/g, '').trim();

            // Bersihkan string
            continuationText = cleanJsonString(continuationText);

            // Logging tambahan untuk debugging
            console.log(`Respons AI untuk kelanjutan bab (Percobaan ${attempts}):`, continuationText);

            // Cek apakah respons adalah JSON (tidak diharapkan pada kelanjutan)
            if (continuationText.startsWith('{') && continuationText.endsWith('}')) {
                console.warn(`Percobaan ${attempts}: Diterima JSON saat kelanjutan, mengabaikan.`);
                continue; // Abaikan dan coba lagi
            }

            // Hitung jumlah kata dalam konten kelanjutan
            const continuationWordCount = countWords(continuationText);

            // Pastikan bahwa kelanjutan menambah kata
            if (continuationWordCount > previousWordCount) {
                finalContent = continuationText;
                previousWordCount = continuationWordCount;
            } else {
                console.warn(`Percobaan ${attempts}: Konten kelanjutan tidak menambah kata. Coba ulang.`);
                continue; // Coba lagi
            }

            // Hitung jumlah kata setelah penambahan
            const totalWordCount = previousWordCount;
            console.log(`Percobaan ${attempts}: Total kata setelah kelanjutan: ${totalWordCount}`);

            // Jika jumlah kata sudah memenuhi, potong jika perlu dan kembalikan
            if (totalWordCount >= minWords) {
                if (totalWordCount > maxWords) {
                    finalContent = finalContent.split(/\s+/).slice(0, maxWords).join(' ');
                }
                // Ganti asteris dengan HTML
                finalContent = replaceAsterisWithHTML(finalContent);
                return finalContent.trim();
            }
        } catch (error) {
            console.error(`Error pada kelanjutan percobaan ${attempts}:`, error);
            if (attempts >= maxRetries) {
                // Jika sudah mencapai maxRetries, return konten terakhir meskipun < minWords
                console.warn(`Percobaan ${attempts}: Tidak dapat mencapai jumlah kata minimal. Menggunakan konten terakhir.`);
                finalContent = replaceAsterisWithHTML(finalContent);
                return finalContent.trim();
            }
        }
    }

    // Setelah keluar dari loop, cek apakah jumlah kata masih < minWords
    if (countWords(finalContent) < minWords) {
        console.warn(`Setelah ${attempts} percobaan, jumlah kata masih kurang dari ${minWords}. Menggunakan konten terakhir.`);
    }

    // Ganti asteris dengan HTML sebelum mengembalikan
    finalContent = replaceAsterisWithHTML(finalContent);
    return finalContent.trim();
}

// Route untuk menangani form submission
app.post('/generate', async (req, res) => {
    const { title, mainIdea, additionalInfo, author, coverImage } = req.body;

    // Validasi input dasar
    if (!title || !mainIdea) {
        return res.status(400).send("Judul dan ide pokok diperlukan.");
    }

    // Buat ID unik untuk e-book
    const ebookId = uuidv4();

    // Membuat prompt berdasarkan input pengguna dengan blok kode JSON
    const prompt = `
Buatlah sebuah e-book dengan judul "${title}" dan ide pokok sebagai berikut:
${mainIdea}
${additionalInfo ? `Informasi tambahan: ${additionalInfo}` : ''}
    
E-book harus mencakup:
1. Kata Pengantar (1 halaman)
2. Daftar Isi (1 halaman)
3. Detail setiap bab dengan struktur berikut:
   - Judul Bab
   - Identifikasi Masalah
   - Integrasi 5W+1H (Who, What, When, Where, Why, How) secara tidak langsung dalam contoh permasalahan atau penjelasan, jangan tampilkan text (Who, What, When, Where, Why, How) nya!, buat 5W+1H dalam struktur
   - Analisis Mendalam
   - Kesimpulan
    
Pastikan setiap bab memiliki konten yang mendalam dan terstruktur dengan baik sesuai dengan struktur di atas. Gunakan bahasa yang jelas dan rinci, sertakan contoh dan studi kasus jika perlu. Setiap bab harus memiliki minimal 4.000 kata dan maksimal 15.000 kata atau setara dengan minimal 8 halaman A4. Format konten menggunakan HTML untuk styling, seperti <b> untuk teks tebal dan <ul>/<ol> untuk daftar. Berikan hasil dalam format JSON murni tanpa tambahan karakter atau format lainnya. Struktur JSON harus memiliki field "preface" dan "chapters" (array dengan "title" dan "content").

Catatan:
- Tidak perlu menampilkan label seperti "Identifikasi Masalah:" atau "Kesimpulan:". Langsung berikan dalam kalimat lengkap saja.
- Jika ingin membuat bold atau list, pakai format HTML (jangan pakai *).
- Gunakan format rapi seperti jika ada contoh list pakai list HTML, pakai <br> dan sebagainya.
`;

    try {
        // Mengirim permintaan ke AI untuk kata pengantar dan daftar isi terlebih dahulu
        const prefacePrompt = `
Buatlah Kata Pengantar untuk e-book dengan judul "${title}" dan ide pokok sebagai berikut:
${mainIdea}
${additionalInfo ? `Informasi tambahan: ${additionalInfo}` : ''}
    
Gunakan bahasa yang jelas dan rinci, sertakan contoh dan studi kasus jika perlu. Format konten menggunakan HTML untuk styling, seperti <b> untuk teks tebal dan <ul>/<ol> untuk daftar. Jangan gunakan asteris (*) atau tanda lainnya untuk formatting. Berikan hasil dalam format JSON murni tanpa tambahan karakter atau format lainnya. Berikut adalah contoh struktur JSON yang diharapkan:
    
\`\`\`json
{
    "preface": "<p>Kata pengantar...</p>",
    "chapters": [
        {
            "title": "Judul Bab 1",
            "content": "<p>Konten bab 1...</p>"
        },
        {
            "title": "Judul Bab 2",
            "content": "<p>Konten bab 2...</p>"
        }
    ]
}
\`\`\`
    
Pastikan JSON valid dan tidak mengandung karakter kontrol atau kesalahan format lainnya. Jangan tambahkan teks atau penjelasan apapun selain JSON.
`;

        // Logging tambahan untuk debugging
        console.log("Mengirim prompt untuk Kata Pengantar dan Daftar Isi:", prefacePrompt);

        const prefaceResult = await model.generateContent(prefacePrompt);
        let prefaceResponseText = prefaceResult.response.text().replace(/```json|```/g, '').trim();

        // Logging tambahan untuk debugging
        console.log("Respons AI untuk Kata Pengantar dan Daftar Isi:", prefaceResponseText);

        prefaceResponseText = cleanJsonString(prefaceResponseText);
        const prefaceJsonMatch = prefaceResponseText.match(/{[\s\S]*}/);
        let prefaceJsonText = prefaceJsonMatch ? prefaceJsonMatch[0] : prefaceResponseText;

        // Logging untuk melihat JSON yang akan diparse
        console.log("JSON yang akan diparse untuk Kata Pengantar dan Daftar Isi:", prefaceJsonText);

        let prefaceContent;
        let chaptersInfo;
        try {
            const prefaceJson = parseJsonWithRetry(prefaceJsonText, 3);
            if (!prefaceJson.preface || !Array.isArray(prefaceJson.chapters)) {
                throw new Error("Struktur JSON tidak sesuai untuk Kata Pengantar dan Daftar Isi.");
            }
            prefaceContent = replaceAsterisWithHTML(prefaceJson.preface);
            chaptersInfo = prefaceJson.chapters; // Asumsi chaptersInfo berisi judul-judul bab
        } catch (jsonError) {
            console.error("Error parsing JSON untuk Kata Pengantar dan Daftar Isi:", jsonError);
            console.log("Response Text:", prefaceResponseText);
            return res.status(500).send("Terjadi kesalahan saat memproses Kata Pengantar dan Daftar Isi.");
        }

        // Mendapatkan daftar judul bab dari chaptersInfo
        const chapterTitles = chaptersInfo.map(chapter => chapter.title);

        // Inisialisasi array untuk menyimpan konten bab
        let chapters = [];

        // Loop melalui setiap judul bab dan generate konten
        for (let i = 0; i < chapterTitles.length; i++) {
            const chapterTitle = chapterTitles[i];
            const chapterPrompt = `
Buatlah sebuah bab dengan judul "${chapterTitle}" untuk e-book dengan judul "${title}" dan ide pokok sebagai berikut:
${mainIdea}
${additionalInfo ? `Informasi tambahan: ${additionalInfo}` : ''}
    
Struktur bab harus mencakup:
- Judul Bab
- Identifikasi Masalah
- Integrasi 5W+1H (Who, What, When, Where, Why, How) secara tidak langsung dalam contoh permasalahan atau penjelasan, jangan tampilkan text (Who, What, When, Where, Why, How) nya!, buat 5W+1H dalam struktur
- Analisis Mendalam
- Kesimpulan
    
Pastikan bab ini memiliki konten yang sangat mendalam dan terstruktur dengan baik. Gunakan bahasa yang jelas dan rinci, sertakan contoh dan studi kasus jika perlu. Bab ini harus memiliki minimal 4.000 kata dan maksimal 15.000 kata atau setara dengan minimal 8 halaman A4. Format konten menggunakan HTML untuk styling, seperti <b> untuk teks tebal dan <ul>/<ol> untuk daftar. Jangan gunakan asteris (*) atau tanda lainnya untuk formatting. Berikan hasil dalam format JSON murni tanpa tambahan karakter atau format lainnya. Struktur JSON harus memiliki field "title" dan "content".

Catatan:
- Tidak perlu menampilkan label seperti "Identifikasi Masalah:" atau "Kesimpulan:". Langsung berikan dalam kalimat lengkap saja.
- Jika ingin membuat bold atau list, pakai format HTML (jangan pakai *).
- Gunakan format rapi seperti jika ada contoh list pakai list HTML, pakai <br> dan sebagainya.
- Buatlah konten yang lebih detail dan 2x lebih panjang dari konten yang telah dihasilkan sebelumnya.
`;

            // Logging tambahan untuk debugging
            console.log(`Mengirim prompt untuk bab "${chapterTitle}":`, chapterPrompt);

            // Menghasilkan konten bab dengan validasi kata
            try {
                const chapterContent = await generateChapter(
                    model,
                    chapterPrompt,
                    4000,    // minWords
                    15000,   // maxWords
                    10       // maxRetries
                );

                chapters.push({
                    title: chapterTitle,
                    content: chapterContent
                });
                console.log(`Bab "${chapterTitle}" berhasil dihasilkan.`);
            } catch (chapterError) {
                console.error(`Gagal menghasilkan bab "${chapterTitle}":`, chapterError);
                return res.status(500).send(`Gagal menghasilkan bab "${chapterTitle}".`);
            }
        }

        // Simpan data e-book
        ebooks[ebookId] = {
            title,
            author: author || "Penulis Otomatis",
            coverImage: coverImage || null,
            preface: prefaceContent,
            chapters: chapters
        };

        res.render('result', { ebookId });
    } catch (error) {
        console.error("Error dalam proses pembuatan e-book:", error);
        res.status(500).send("Terjadi kesalahan saat memproses pembuatan e-book.");
    }
    });

// Route untuk menampilkan e-book sebagai HTML
app.get('/view/:id', (req, res) => {
    const ebookId = req.params.id;
    const ebook = ebooks[ebookId];

    if (!ebook) {
        return res.status(404).send("E-Book tidak ditemukan.");
    }

    res.render('ebook_template', { 
        title: ebook.title, 
        author: ebook.author, 
        preface: ebook.preface, 
        chapters: ebook.chapters,
        coverImage: ebook.coverImage
    });
});

// Menjalankan server
const PORT = process.env.PORT || 3003;
app.listen(PORT, () => {
    console.log(`Server berjalan di http://localhost:${PORT}`);
});
