const express = require("express");
const cors = require("cors");
const fs = require("fs");
const { GoogleGenerativeAI } = require("@google/generative-ai");

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static("public"));

// Load API Key
const keyData = JSON.parse(fs.readFileSync("./key.json", "utf-8"));
const apiKey = keyData.api_key;

// Load Custom Prompt
const customPrompt = fs.readFileSync("./prompt.txt", "utf-8");

const genAI = new GoogleGenerativeAI(apiKey);
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

let chatHistory = [];

app.post("/chat", async (req, res) => {
    try {
        const { message } = req.body;
        if (!message) return res.status(400).json({ error: "Bro, input lu kosong wkwk" });

        // Gabung history + custom prompt
        const context = chatHistory.map(chat => `${chat.role}: ${chat.text}`).join("\n");
        const fullPrompt = `${customPrompt}\n\n${context}\nUser: ${message}\nBot:`;

        const result = await model.generateContent(fullPrompt);
        const reply = result.response.text().replace(/(\*\*?)(.*?)\1/g, '<b>"$2"</b>');

        // Simpan chat ke history
        chatHistory.push({ role: "User", text: message });
        chatHistory.push({ role: "Bot", text: reply });

        if (chatHistory.length > 10) chatHistory = chatHistory.slice(-10);

        res.json({ reply });
    } catch (error) {
        console.error("Error:", error);
        res.status(500).json({ error: "Yah, ada error nih bro" });
    }
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server nyala di http://localhost:${PORT}`);
});
